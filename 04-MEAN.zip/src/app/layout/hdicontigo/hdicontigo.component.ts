import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hdicontigo',
  templateUrl: './hdicontigo.component.html',
  styleUrls: ['./hdicontigo.component.css']
})
export class HdicontigoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
