import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siniestro',
  templateUrl: './siniestro.component.html',
  styleUrls: ['./siniestro.component.css']
})
export class SiniestroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
