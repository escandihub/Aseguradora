const ClienteSchema = require('../Models/Usuario.model');

exports.allCliente = (req, res) => {
    
}