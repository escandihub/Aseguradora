module.exports = {
    AUTH0_DOMAIN: 'ds123399.mlab.comds123399.mlab.com',
    API: 'http://127.0.0.1:3000/api',
    secret:'meansecure',
    MONGO_URI: 'mongodb://Xnecro:N0paginaweb@ds123399.mlab.com:23399/mean'
};